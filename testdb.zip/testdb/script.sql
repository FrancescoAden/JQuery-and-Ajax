CREATE TABLE employee
(	id int IDENTITY(1,1) PRIMARY KEY,
	firstname char (30)
	lastname char (30),
);
GO


INSERT INTO employee (id, firstname, lastname)
VALUES('Birch','Joseph');
GO

INSERT INTO employee (id, firstname, lastname)
VALUES('Cook','George');
GO